<?php
header("Location: ejercicioF02a.php");
die();
?>