<?php
    $a = 4;
    $b = 8;
    $c = 5;
    if ($a > $b and $a>$c){
        echo "El mayor es--> ".$a;
    }elseif ($b > $a and $b>$c){
        echo "El mayor es-->".$b;
    }else{
        echo "El mayor es--->".$c;
    }
?>