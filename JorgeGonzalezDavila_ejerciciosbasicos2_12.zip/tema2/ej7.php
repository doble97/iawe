<?php
    $tabla = rand(1,10);
    for($i=0; $i<=10; $i++){
        echo "<p>$tabla*$i = ".$tabla*$i."</p>";
    }
?>