<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php 
        echo '<h3>EJERCICIO 2</h3>';
        include 'ej2.php';
        
        echo '<h3>EJERCICIO 3</h3>';
        include 'ej3.php';

        echo '<h3>EJERCICIO 4</h3>';
        include 'ej4.php';

        echo '<h3>EJERCICIO 5</h3>';
        include 'ej5.php';

        echo '<h3>EJERCICIO 6</h3>';
        include 'ej6.php';

        echo '<h3>EJERCICIO 7</h3>';
        include 'ej7.php';

        echo '<h3>EJERCICIO 8</h3>';
        include 'ej8.php';

        echo '<h3>EJERCICIO 9</h3>';
        include 'ej9.php';

        echo '<h3>EJERCICIO 10</h3>';
        include 'ej10.php';

        echo '<h3>EJERCICIO 11</h3>';
        include 'ej11.php';

        echo '<h3>EJERCICIO 12</h3>';
        include 'ej12.php';
    ?>
</body>
</html>