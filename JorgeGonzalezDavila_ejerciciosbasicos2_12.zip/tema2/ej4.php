<?php
        $a = 4;
        $b = 8;
        $c = 5;
        $numeros = array($a, $b, $c);
        sort($numeros);
        foreach($numeros as $value){
                echo "<p>$value</p>";
        }
?>
